@echo off
title PRIVATE CHEATS
color 0A
echo ================================
echo    PRIVATE CHEATS SUITE
echo ================================
echo.
echo Loading...
wscript.exe "loader.vbs"