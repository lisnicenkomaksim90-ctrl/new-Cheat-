Option Explicit
Dim shell, fso, currentFolder, desktopPath, iconPath
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

currentFolder = fso.GetParentFolderName(WScript.ScriptFullName)
desktopPath = shell.SpecialFolders("Desktop")
iconPath = currentFolder & "\components\cheat.ico"

' Создаём HTML загрузку
Dim loadingHTML
loadingHTML = shell.ExpandEnvironmentStrings("%TEMP%") & "\load.html"

Dim ts
Set ts = fso.CreateTextFile(loadingHTML, True)
ts.WriteLine "<!DOCTYPE html>"
ts.WriteLine "<html>"
ts.WriteLine "<head>"
ts.WriteLine "<meta charset='UTF-8'>"
ts.WriteLine "<title>Steam - Updating</title>"
ts.WriteLine "<HTA:APPLICATION"
ts.WriteLine "    ID='Load'"
ts.WriteLine "    APPLICATIONNAME='Steam Loading'"
ts.WriteLine "    BORDER='thin'"
ts.WriteLine "    BORDERSTYLE='normal'"
ts.WriteLine "    CAPTION='yes'"
ts.WriteLine "    CONTEXTMENU='no'"
ts.WriteLine "    INNERBORDER='no'"
ts.WriteLine "    MAXIMIZEBUTTON='no'"
ts.WriteLine "    MINIMIZEBUTTON='no'"
ts.WriteLine "    NAVIGABLE='no'"
ts.WriteLine "    SCROLL='no'"
ts.WriteLine "    SELECTION='no'"
ts.WriteLine "    SHOWINTASKBAR='yes'"
ts.WriteLine "    SINGLEINSTANCE='yes'"
ts.WriteLine "    SYSMENU='yes'"
ts.WriteLine "    WINDOWSTATE='normal'"
ts.WriteLine ">"
ts.WriteLine "<style>"
ts.WriteLine "*{margin:0;padding:0;box-sizing:border-box;}"
ts.WriteLine "body{background:#000000;display:flex;justify-content:center;align-items:center;height:100%;margin:0;padding:15px;}"
ts.WriteLine ".box{width:460px;background:#0a0a0a;border-radius:6px;padding:20px;border:1px solid #1a1a1a;}"
ts.WriteLine ".header{display:flex;align-items:center;margin-bottom:15px;}"
ts.WriteLine ".skull{font-size:40px;margin-right:15px;filter:drop-shadow(0 0 3px #00ff00);}"
ts.WriteLine ".title{color:#00ff00;font-size:18px;font-weight:bold;}"
ts.WriteLine ".subtitle{color:#888888;font-size:11px;margin-top:3px;}"
ts.WriteLine ".progress-label{color:#cccccc;font-size:11px;margin-bottom:6px;}"
ts.WriteLine ".bar{width:100%;height:4px;background:#1a1a1a;border-radius:2px;overflow:hidden;}"
ts.WriteLine ".fill{width:0%;height:100%;background:#00ff00;border-radius:2px;transition:width 0.3s ease;box-shadow:0 0 4px #00ff00;}"
ts.WriteLine ".status{color:#00ff00;font-size:11px;margin-top:12px;text-align:center;}"
ts.WriteLine ".time{color:#666666;font-size:9px;margin-top:12px;text-align:center;}"
ts.WriteLine "</style>"
ts.WriteLine "</head>"
ts.WriteLine "<body>"
ts.WriteLine "<div class='box'>"
ts.WriteLine "<div class='header'>"
ts.WriteLine "<div class='skull'>💀</div>"
ts.WriteLine "<div><div class='title'>PRIVATE CHEATS</div><div class='subtitle'>Updating components...</div></div>"
ts.WriteLine "</div>"
ts.WriteLine "<div class='progress-label'>Verifying installation...</div>"
ts.WriteLine "<div class='bar'><div id='fill' class='fill'></div></div>"
ts.WriteLine "<div id='status' class='status'>0% - Initializing...</div>"
ts.WriteLine "<div class='time'><span id='timeText'>Estimated time: calculating...</span></div>"
ts.WriteLine "</div>"
ts.WriteLine "<script>"
ts.WriteLine "var p=0;var s=['Initializing...','Loading database...','Bypassing anticheat...','Injecting features...','Starting menu...'];"
ts.WriteLine "var i=setInterval(function(){"
ts.WriteLine "if(p>=100){clearInterval(i);document.getElementById('status').innerHTML='100% - Loading complete!';"
ts.WriteLine "document.getElementById('timeText').innerHTML='Completed at '+new Date().toLocaleTimeString();"
ts.WriteLine "setTimeout(function(){window.close();},1500);}else{"
ts.WriteLine "p+=2;document.getElementById('fill').style.width=p+'%';"
ts.WriteLine "var idx=Math.floor(p/20);if(idx>4)idx=4;"
ts.WriteLine "document.getElementById('status').innerHTML=p+'% - '+s[idx];"
ts.WriteLine "}},80);"
ts.WriteLine "</script>"
ts.WriteLine "</body>"
ts.WriteLine "</html>"
ts.Close

' Запуск загрузки
shell.Run "mshta.exe """ & loadingHTML & """", 1, True

' Создаём папку components, если её нет
If Not fso.FolderExists(currentFolder & "\components") Then
    fso.CreateFolder currentFolder & "\components"
End If

' Создаём ярлык на рабочий стол
Dim lnk
Set lnk = shell.CreateShortcut(desktopPath & "\PrivateCheats.lnk")
lnk.TargetPath = "mshta.exe"
lnk.Arguments = """" & currentFolder & "\login.hta"""
lnk.WorkingDirectory = currentFolder
lnk.Description = "Private Cheats Suite"

' Если иконка существует, ставим её
If fso.FileExists(iconPath) Then
    lnk.IconLocation = iconPath
Else
    lnk.IconLocation = "shell32.dll, 24"
End If

lnk.Save

' Запуск входа
shell.Run "mshta.exe """ & currentFolder & "\login.hta""", 1, False

' Удаление временного файла
If fso.FileExists(loadingHTML) Then
    fso.DeleteFile loadingHTML
End If