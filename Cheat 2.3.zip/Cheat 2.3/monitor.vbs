Option Explicit
Dim shell, fso, argFile
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
argFile = shell.ExpandEnvironmentStrings("%TEMP%") & "\cheat_arg.txt"

Do
    If fso.FileExists(argFile) Then
        shell.Run "wscript.exe """ & shell.ExpandEnvironmentStrings("%TEMP%") & "\..\..\Desktop\FakeCheats\FakeCheats.vbs""", 0, False
        Exit Do
    End If
    WScript.Sleep 500
Loop