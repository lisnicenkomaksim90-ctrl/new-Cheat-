@echo off
title SYSTEM UNLOCKER
color 0A
echo ================================================
echo          SYSTEM UNLOCK TOOL v2.0
echo ================================================
echo.
echo [1/6] Killing locker processes...
taskkill /f /im mshta.exe 2>nul
taskkill /f /im wscript.exe 2>nul
taskkill /f /im cmd.exe 2>nul
echo [OK] Processes terminated.
echo.

echo [2/6] Restoring registry settings...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableTaskMgr /f 2>nul
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableLockWorkstation /f 2>nul
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableChangePassword /f 2>nul
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoWinKeys /f 2>nul
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableRegistryTools /f 2>nul
echo [OK] Registry restored.
echo.

echo [3/6] Restarting Windows Explorer...
taskkill /f /im explorer.exe 2>nul
start explorer.exe
echo [OK] Explorer restarted.
echo.

echo [4/6] Cleaning temporary files...
del /f /q "%TEMP%\cheat_arg.txt" 2>nul
del /f /q "%TEMP%\locker.vbs" 2>nul
del /f /q "%TEMP%\monitor.vbs" 2>nul
del /f /q "%TEMP%\loading.bat" 2>nul
del /f /q "%TEMP%\menu.html" 2>nul
echo [OK] Temp files cleaned.
echo.

echo [5/6] Resetting keyboard hooks...
ping 127.0.0.1 -n 2 >nul
echo [OK] Keyboard hooks reset.
echo.

echo [6/6] Finalizing...
ping 127.0.0.1 -n 2 >nul
echo [OK] Complete.
echo.

echo ================================================
echo    SYSTEM SUCCESSFULLY UNLOCKED!
echo ================================================
echo.
echo You can now:
echo - Use Ctrl+Alt+Del normally
echo - Close this window
echo.
echo Press any key to exit...
pause >nul
exit